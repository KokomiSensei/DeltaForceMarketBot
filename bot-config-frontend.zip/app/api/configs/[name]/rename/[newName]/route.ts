import { type NextRequest, NextResponse } from "next/server"

// Mock storage for configurations
const mockConfigs: any[] = [
  {
    name: "default",
    lowest_price: 100,
    volume: 1000,
    screenshot_delay: 2000,
    debug_mode: false,
    target_schema_index: 0,
  },
  {
    name: "high-volume",
    lowest_price: 50,
    volume: 5000,
    screenshot_delay: 1000,
    debug_mode: true,
    target_schema_index: 1,
  },
]

export async function POST(request: NextRequest, { params }: { params: { name: string; newName: string } }) {
  try {
    const oldName = decodeURIComponent(params.name)
    const newName = decodeURIComponent(params.newName)

    const configIndex = mockConfigs.findIndex((config) => config.name === oldName)

    if (configIndex === -1) {
      return NextResponse.json({ error: "Configuration not found" }, { status: 404 })
    }

    // Check if new name already exists
    const existingConfig = mockConfigs.find((config) => config.name === newName)
    if (existingConfig) {
      return NextResponse.json({ error: "Configuration with this name already exists" }, { status: 409 })
    }

    // Rename the configuration
    mockConfigs[configIndex].name = newName

    return NextResponse.json({ success: true })
  } catch (error) {
    return NextResponse.json({ error: "Failed to rename configuration" }, { status: 500 })
  }
}
